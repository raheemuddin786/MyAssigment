package com.wishary.registrationandlogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;

import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

/**
 * A login screen that offers login via email/password.
 */
public class LoginActivity extends AppCompatActivity {

    private Button registrationButton, loginButton;
    private EditText email_to_login, password_to_login;

    private ProgressDialog progressDialog;
    private Session session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Toolbar toolBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolBar);
        session = new Session(LoginActivity.this);
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        registrationButton = (Button) findViewById(R.id.registration_button);
        loginButton = (Button) findViewById(R.id.signin_button);
        email_to_login = (EditText) findViewById(R.id.email_to_login);
        password_to_login = (EditText) findViewById(R.id.password_to_login);


        registrationButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),
                        RegistrationActivity.class);
                startActivity(intent);
                finish();
            }
        });

        loginButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = email_to_login.getText().toString();
                String password = password_to_login.getText().toString();

                if (email.trim().length() > 0 && password.trim().length() > 0) {
                    checkLogin(email, password);
                } else {
                    Snackbar.make(v, "Please enter the credentials!", Snackbar.LENGTH_LONG)
                            .show();
                }
            }
        });
    }

    private void checkLogin(final String email, final String password) {
        String tag_string_req = "req_login";
        try {
            progressDialog.setMessage("Logging in ...");
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("username", email);
            jsonBody.put("password", password);
            final String mRequestBody = jsonBody.toString();
            showDialog();

            StringRequest strReq = new StringRequest(Request.Method.POST,
                    AppURLs.LOGIN_URL, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    Log.i(this.getClass().getSimpleName(),"in onResponse"+response);
                    hideDialog();

                    try {
                        JSONObject jObj = new JSONObject(response);
                        String token = jObj.getString("token");
                        if (token != null) {
                            session.setLogin(true);
                            User userObj=new User(token,jObj.getJSONObject("user"));
                            Log.i(this.getClass().getSimpleName(),"user:"+userObj.getMail());
                            Intent intent = new Intent(LoginActivity.this,
                                    MainActivity.class);
                            intent.putExtra("loggedUserObj",userObj);
                            startActivity(intent);
                            finish();
                        } else {
                          /*  String errorMsg = jObj.getString("error_msg");*/
                            Log.w(this.getClass().getSimpleName(),"Error:response"+response);
                            Toast.makeText(getApplicationContext(),
                                    response, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        Log.e(this.getClass().getSimpleName(),"Erro:JSONException"+e.getCause());
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(this.getClass().getSimpleName(),"Error:Login:onErrorResponse:"+error.getCause());
                    Toast.makeText(getApplicationContext(),
                            "Failed to login, Please check login credentials.", Toast.LENGTH_LONG).show();
                    hideDialog();
                }
            }) {

                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }

                @Override
                public String getBodyContentType()
                {
                    return "application/json";
                }

            };

            // Adding request to  queue
            AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showDialog() {
        if (!progressDialog.isShowing())
            progressDialog.show();
    }

    private void hideDialog() {
        if (progressDialog.isShowing())
            progressDialog.dismiss();
    }
}