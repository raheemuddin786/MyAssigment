package com.wishary.registrationandlogin;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.StringRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

public class RegistrationActivity extends AppCompatActivity {

    private TextView tvLogin;
    private EditText fullName, email_to_register, password_to_register,email_cnf_to_register, password_cnf_to_register;
    private Button registerButton;
    private Session session;
    private ProgressDialog pDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        pDialog = new ProgressDialog(this);
        pDialog.setCancelable(false);
        session = new Session(RegistrationActivity.this);

        if (session.getLoggedIn()) {
            Intent intent = new Intent(RegistrationActivity.this,
                    MainActivity.class);
            startActivity(intent);
            finish();
        }
        registerButton = (Button) findViewById(R.id.register_button);
        fullName = (EditText) findViewById(R.id.fullname_register);
        email_to_register = (EditText) findViewById(R.id.email_register);
        password_to_register = (EditText) findViewById(R.id.password_register);
        email_cnf_to_register = (EditText) findViewById(R.id.email_cnf_register);
        password_cnf_to_register = (EditText) findViewById(R.id.password_cnf_register);
        tvLogin = (TextView) findViewById(R.id.tv_signin);

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = fullName.getText().toString();
                String email = email_to_register.getText().toString();
                String password = password_to_register.getText().toString();
                String emailCnf = email_cnf_to_register.getText().toString();
                String passwordCnf = password_cnf_to_register.getText().toString();

                if (!name.isEmpty() && !email.isEmpty() && !password.isEmpty() && !emailCnf.isEmpty() && !passwordCnf.isEmpty()) {
                    if (email.equalsIgnoreCase(emailCnf) && password.equalsIgnoreCase(passwordCnf)){
                        registerUser(name, email, password);
                    }else{
                        Snackbar.make(v, "mismatch in credentials!", Snackbar.LENGTH_LONG)
                                .show();
                    }
                } else {
                    Snackbar.make(v, "Please enter the credentials!", Snackbar.LENGTH_LONG)
                            .show();
                }
            }
        });

        tvLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegistrationActivity.this,
                        LoginActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void registerUser(final String name, final String email,
                              final String password) {
        // Tag used to cancel the request
        String tag_string_req = "req_register";
        try {
            pDialog.setMessage("Registering ...");
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("name", name);
            jsonBody.put("mail", email);
            jsonBody.put("conf_mail", email);
            jsonBody.put("pass", password);
            jsonBody.put("pass2", password);
            jsonBody.put("status", 1);
            final String mRequestBody = jsonBody.toString();
            showDialog();

            StringRequest strReq = new StringRequest(Request.Method.POST,
                    AppURLs.REGISTER_URL, new Response.Listener<String>() {

                @Override
                public void onResponse(String response) {
                    hideDialog();

                    try {
                        JSONObject jObj = new JSONObject(response);
                        String uid = jObj.getString("uid");
                        if (uid != null) {

                            Intent intent = new Intent(
                                    RegistrationActivity.this,
                                    LoginActivity.class);
                            Toast.makeText(getApplicationContext(),
                                    "Registration done successfully. Please login", Toast.LENGTH_LONG).show();
                            startActivity(intent);
                            finish();
                        } else {
                            Log.w(this.getClass().getSimpleName(),"Error:response"+response);
                            String errorMsg = jObj.getString("error_msg");
                            Toast.makeText(getApplicationContext(),
                                    errorMsg, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        Log.e(this.getClass().getSimpleName(),"Erro:JSONException"+e.getCause());
                        e.printStackTrace();
                    }

                }
            }, new Response.ErrorListener() {

                @Override
                public void onErrorResponse(VolleyError error) {
                    Log.e(this.getClass().getSimpleName(),"Error:Login:onErrorResponse:"+error.getCause());
                    Toast.makeText(getApplicationContext(),
                            "Failed to register user. Please try after sometime.", Toast.LENGTH_LONG).show();
                    hideDialog();
                }
            }) {
                @Override
                public byte[] getBody() throws AuthFailureError {
                    try {
                        return mRequestBody == null ? null : mRequestBody.getBytes("utf-8");
                    } catch (UnsupportedEncodingException uee) {
                        VolleyLog.wtf("Unsupported Encoding while trying to get the bytes of %s using %s", mRequestBody, "utf-8");
                        return null;
                    }
                }

                @Override
                public String getBodyContentType()
                {
                    return "application/json";
                }
            };

            AppController.getInstance().addToRequestQueue(strReq, tag_string_req);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void showDialog() {
        if (!pDialog.isShowing())
            pDialog.show();
    }

    private void hideDialog() {
        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}
