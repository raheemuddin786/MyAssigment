package com.wishary.registrationandlogin;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private Button btnLogout;
    private Session session;
    private TextView uid,username,email;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolBar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolBar);
        btnLogout = (Button) findViewById(R.id.btnLogout);
        session = new Session(MainActivity.this);


        if (!session.getLoggedIn()) {
            logoutUser();
        }

        User loggedUserInfo=(User) getIntent().getSerializableExtra("loggedUserObj");
        if(session.getLoggedIn() && loggedUserInfo==null)
            loggedUserInfo=session.getLoggedUser();

        uid =(TextView)findViewById(R.id.userid);
        username=(TextView)findViewById(R.id.username);
        email=(TextView)findViewById(R.id.email);


        if(session.getLoggedIn() && loggedUserInfo!=null) {
            session.setLoggedUser(loggedUserInfo);
            Log.i(this.getClass().getSimpleName(), "user:" + loggedUserInfo.getMail());
            uid.setText("UID:"+loggedUserInfo.getUid());
            username.setText("User Name:"+loggedUserInfo.getName());
            email.setText("Email:"+loggedUserInfo.getMail());
        }
        btnLogout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                logoutUser();
            }
        });
    }


    private void logoutUser() {
        session.setLogin(false);
        Intent intent = new Intent(MainActivity.this, LoginActivity.class);
        startActivity(intent);
        finish();
    }
}
