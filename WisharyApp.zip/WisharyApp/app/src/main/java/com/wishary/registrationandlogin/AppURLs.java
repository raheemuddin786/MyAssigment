package com.wishary.registrationandlogin;

/**
 * Created by Syed Raheem Udin on 10/11/2016.
 */
public class AppURLs {
    public static String BASE_URL = "http://dev.planet11.in/drupalgap/user/";
    public static String REGISTER_URL = BASE_URL+"register.json";
    public static String LOGIN_URL = BASE_URL+"login.json";
}
